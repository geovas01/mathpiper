
   /*
      ScatterPlotApplet can draw a scatter plot from two columns of data.
      It will also draw a regression line and display the intercept and
      slope of that line and the standard error for the linear approximation
      of the data.  The user can enter the data by hand.  The applet can be
      configured to load one or more data files, if the names of the data
      files are provided as applet parameters.  (The data files should be
      in the same directory as the Web page on which the applet is shown.)

      Applet parameters with names data, data1, data2, ... can be used.
      The value of the parameter should be a file name.  Use of the
      name "data" is optional, but you can't use the name data2 unless
      you use data1, you can't use data3 unless you use data2, and so on.

      The applet can actually plot any function of the data against any
      other function.  The columns of data are named "a" and "b".  The
      user can specify any expression involving  "a", "b", and "rowNumber"
      to be graphed on the horizontal axis and any other expression to
      be graphed on the vertical axis.  Expressions can use the operators
      + - * / ^ and !, where ^ is exponentiation.  They can also use
      the functions sin, cos, tan, sec, csc, cot, arcsin, arccos, arctan,
      ln, log2, log10, exp, abs, sqrt, cubert, trunc, round, and ceiling.

      If a row of the data contains an empty data value, that row is
      completely ignored (even if the other data value on the row is
      non-empty).

      When the user is inputting data by hand, if the user is in the 
      last row of data and presses return or down-arrow, then a new
      row is added to the table.  The arrow keys and tab key can be
      used to move among the rows of the table.


      This applet is part of the mathbeans package, and it must be used in
      an <applet> tag with code="mathbeans.ScatterPlotApplet.class" and with
      mathbeans.jar available as an archive.  See the mathbeans web site
      at http://math.hws.edu/mathbeans/ for more information.

      David Eck (eck@hws.edu, http://math.hws.edu/eck/)
      28 August 1999
   */


   package mathbeans;

   import mathbeans.awt.*;
   import mathbeans.data.*;
   import mathbeans.draw.*;

   import java.awt.*;
   import java.awt.event.*;
   import java.applet.Applet;


   public class ScatterPlotApplet extends Applet {

      public void init() {

         /*  The init method sets up the interface of the applet.  For a "mathbean"
          *  applet, this is all you have to do, since interface components take care
          *  of themselves once they have been created and properly configured.
          *     The entire applet is filled by a "MathBeanPanel", which coordinates
          *  the activities of the mathematical components that it contains.
          *  "panel.setInsetGap(5) leaves a 5-pixel border between the edge of the
          *  panel and the components that it contains.
          */

         MathBeanPanel panel = new MathBeanPanel();
         panel.setInsetGap(5);
         setLayout(new BorderLayout());
         add(panel,BorderLayout.CENTER);

         /*  Add a DataInputTable to the applet.  Here, the table will have
          *  two columns of input, named "a" and "b".  The variable, table,
          *  is "final" because it is referenced in an anonymous local
          *  later in this method -- this is just a funny requirement in Java.
          */

         final DataTableInput table = new DataTableInput(2);
         panel.add(table, BorderLayout.WEST);

         /*  A file loader displays a list of data files that can
          *  be loaded into the applet.  fileCount is the number of
          *  data file names found.  (If this is zero, I won't 
          *  add the fileLoader to the applet.)
          */

         DataFileChoice fileLoader = new DataFileChoice(table,null,"Load Data:");
         int fileCount = fileLoader.getSourcesFromAppletParameters(this);


         /*  Make a panel where the user can enter expressions to be
          *  plotted.  To allow the table variables a, b, and rowNumber
          *  to be used in these expressions, the expressions have to
          *  be parsed by a Parser that knows about the table variables.
          *  So, I create a parser, add the table variables to it,
          *  and use it for parsing the expressions.
          *     (Note:  In the constructor calls for ExpressionFunctionInput,
          *  the second parameter is given as (String)null rather than just
          *  null because null would be ambiguous between the two types,
          *  String and String[], that would legal in this position.)
          */

         MathBeanPanel expInput = new MathBeanPanel(1,4);
         Parser tableParser = new Parser();
         table.getDataTable().addVariables(tableParser);
         expInput.add(new Label("Plot: ",Label.RIGHT));
         expInput.add( new ExpressionFunctionInput(
                            "xVal", (String)null, tableParser, "A"
                     ) );
         expInput.add(new Label("versus: ",Label.RIGHT));     
         expInput.add( new ExpressionFunctionInput(
                            "yVal", (String)null, tableParser, "S"
                     ) );

         /*  Make a button that the user can use to plot the data.
          *  Setting panel as an ActionListener for the button
          *  makes the panel recompute its contents when the
          *  button is pressed.  This includes the ScatterPlot,
          *  which knows how to draw itself.
          */

         Button computeButton = new Button("Plot the Data");
         computeButton.addActionListener(panel);

         /*  Make a button that the user can use to clear the
          *  data table.  There is no shortcut for doing this
          *  so I have to create a special-purpose anonymous
          *  ActionListener class to do it.
          */

         Button clearButton = new Button("Clear Data");
         clearButton.addActionListener( new ActionListener() { 
              public void actionPerformed(ActionEvent evt) {
                 table.clear();
              }
           } );

         /*  Create a panel to hold the components just created
          *  and add it to the bottom of the main panel.  This
          *  panel looks different depending on whether there
          *  are any data files to be loaded.
          */

         if (fileCount == 0) {
           MathBeanPanel bottom = new MathBeanPanel(1,2);
           MathBeanPanel left = new MathBeanPanel(1,2);
           left.add(clearButton);
           left.add(computeButton);
           bottom.add(left);
           bottom.add(expInput);
           panel.add(bottom,BorderLayout.SOUTH);
         }
         else { 
            MathBeanPanel bottom = new MathBeanPanel(2,2);
            bottom.add(fileLoader);
            bottom.add(expInput);
            bottom.add(clearButton);
            bottom.add(computeButton);
            panel.add(bottom,BorderLayout.SOUTH);
         }

         /*  Create a canvas and add it to the panel.  The call to
          *  panel.setErrorReporter(canvas) means that if an error is
          *  found in user input, an error message will be display on
          *  the canvas.  Otherwise, the error would be reported in
          *  a dialog box, which is probably not a good idea in an applet.
          *     A DisplayCanvas can display various graphical
          *  objects, including axes and graphs.  These objects are subclasses
          *  of the class "Drawable".  In this case the Drawable objects 
          *  displayed by the canvas are a set of axes and the scatter plot.
          *     A DisplayLabel to show some statistics about the date is
          *  also created and added to the top of the applet.  This is
          *  all done in a try..catch statement because calls to parser.parse(String)
          *  will throw a ParseError if the String does not specify a legal
          *  expression.
          */

         canvas = new DisplayCanvas();  // Declared below, outside the init() routine
         panel.setErrorReporter(canvas);
         panel.add(canvas,BorderLayout.CENTER);      
         canvas.add(new Axes());
         try {
            ScatterPlot plot = new ScatterPlot(table.getDataTable(),tableParser.parse("xVal"),tableParser.parse("yVal"));
            canvas.add(plot);
            Parser parser = new Parser();
            plot.addVariables(parser);
            DisplayLabel dl = new DisplayLabel(
                  "Slope = #;  Intercept = #;  Standard Error = #",
                   new Expression[] { parser.parse("slope"), 
                                      parser.parse("intercept"),
                                      parser.parse("correlation") }
               );
            dl.setAlignment(Label.CENTER);
            dl.setBackground(new Color(225,225,225));
            dl.setForeground(new Color(180,0,0));
            dl.setFont(new Font("Serif",Font.PLAIN,14));
            panel.add(dl,BorderLayout.NORTH);
         }
         catch (ParseError e) {
               // Shouldn't happen, except possibly during debugging.
            System.out.println("Unexpected parsing error while setting up ScatterPlotApplet:");
            System.out.println(e.toString());
         }

      } // end init()

      private DisplayCanvas canvas;  // The canvas used in the applet

      public void stop() {
            // When the applet is stopped, be polite by releasing the
            // canvas's fairly large amount of allocated memory.
         canvas.releaseResources();
      }

   } // end class ScatterPlotApplet



------------------------------------------------------------------------
