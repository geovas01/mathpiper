/*
   The ESS is a simple, single-purpose calculator that
   computes the evolutionary stable strategy for a 2-by-2 game.
   The user can enter the four data values.  Some intermediate
   results in the computation of ESS are also displayed.
   
   
   The input data represents a payoff matrix for two players each 
   having access to the same two two strategies.  The names of the 
   two strategies are displayed,
   and they can be configured as applet parameters.
   
       Param name  Default value  Meaning
       ----------  -------------  -------
        label1      Category 1     Name of the first category.
        label2      Category 2     Name of the second category.

   This applet is part of the mathbeans package, and it must be used in
   an <applet> tag with code="mathbeans.ESS.class" and with
   mathbeans.jar available as an archive.  See the mathbeans web site
   at http://math.hws.edu/mathbeans/ for more information. Modified by Jim Ryan
   Sept 30, 2000.
   
   David Eck (eck@hws.edu, http://math.hws.edu/eck/)
   27 August 1999
*/




import mathbeans.awt.*;
import mathbeans.data.*;
import mathbeans.draw.*;

import java.awt.*;
import java.applet.Applet;


public class ESS extends Applet {

   public void init() {

      /*  The init method sets up the interface of the applet.  For a "mathbean"
       *  applet, this is all you have to do, since interface components take
       * care
       *  of themselves once they have been created and properly configured.
       *     The entire applet is filled by a "MathBeanPanel", which coordinates
       *  the activities of the mathematical components that it contains.
       *  "panel.setInsetGap(5) leaves a 3-pixel border between the edge of the
       *  panel and the components that it contains.  The 5 in the constructor
       *  "new MathBeanPanel(5)" means that gaps between components in the panel
       *  will also be 5 pixels wide.
       */

      MathBeanPanel panel = new MathBeanPanel(5);
      panel.setInsetGap(5);
      setLayout(new BorderLayout());
      add(panel,BorderLayout.CENTER);
      
      /*  A Parser is used to convert a String that specifies an expression
       *  into an internal format that can be used for computation.  Variables
       *  can be registered with a parser so that they can be used in such
       *  expressions.
       */

      Parser parser = new Parser();

      /* Get the names to be used as category labels. */

      String label1 = getParameter("label1");
      if (label1 == null)
         label1 = "Strategy 1";
      
      String label2 = getParameter("label2");
      if (label2 == null)
         label2 = "Strategy 2";
         
      /*  The structure of this applet consists of a large area containing
       *  the user input boxes, labels, and intermediate results, with a
       *  single label at the bottom showing the chi-square value.
       *  Here I create a MathBeanPanel for the large, upper area.  The
       *  constructor "new MathBeanPanel()" creates a panel using a 
       *  GridLayout with 4 rows and 4 columns, with gaps of 4 pixels between
       *  the components.
       */
         
      MathBeanPanel inputPanel = new MathBeanPanel(4,4,4);
      inputPanel.setInsetGap(4);
      inputPanel.setBackground(new Color(220,220,220));
      panel.add(inputPanel, BorderLayout.CENTER);
      
      
      /*  Create all the components and add them to the applet.
       *  The input boxes are VariableInputs created by the convenience
       *  method makeInput(), which is defined below.  Results are
       *  displayed in DisplayLabels, which can show the values of
       *  expressions.  This is done inside a try..catch since
       *  the call to parser.parse(String) with throw a ParseError
       *  if the String does not define a legal expression.  (Here,
       *  of course, I don't expect an error, but the ParserError
       *  must be handled in a try..catch nevertheless.)
       */
      
      try {

         inputPanel.add(new Label());  // placeholder for empty space in the GridLayout
         inputPanel.add(new Label("PLAYER 2", Label.RIGHT));
         inputPanel.add(new Label());
         
         inputPanel.add(new Label("PLAYER 1", Label.LEFT));  
         inputPanel.add(new Label("Strategy 1", Label.CENTER));
         inputPanel.add(new Label("Strategy 2", Label.CENTER));
       
         VariableInput a,b,c,d;

         inputPanel.add(new Label(label1,Label.CENTER));
         inputPanel.add(a = makeInput("a",panel,parser));
         inputPanel.add(b = makeInput("b",panel,parser));
         
        
         inputPanel.add(new Label(label2,Label.CENTER));
         inputPanel.add(c = makeInput("c",panel,parser));
         inputPanel.add(d = makeInput("d",panel,parser));
      
         
       DisplayLabel answer = new DisplayLabel("ESS = #",
           parser.parse("(a > c or (a=c and b>d))? 1 : (d > b or (d=b and c>a))? 2 : (b-d)/(b + c -a - d)"));
         answer.setAlignment(Label.CENTER);
         answer.setFont(new Font("Serif",Font.BOLD,14));
         answer.setBackground(new Color(220,220,220));
         answer.setForeground(new Color(180,0,0)); 
         
         panel.add(answer, BorderLayout.SOUTH);
         
      }
     catch (ParseError e) {
            // Shouldn't be an error, but print a message for debugging.
         System.out.println("Unexpected parse error during setup:");
         System.out.println(e.getMessage());
      }
      
   }  // end init()

   
   /*  The makeInput() routine makes a VariableInput box for user input.
    *  The associated variable has a name, and is registered with the
    *  parser so that it can be used later in expressions.  Adding the
    *  panel as a TextListener for the input box will make the panel 
    *  recompute its contents every time the text in the box is changed.
    *  When using a TextListener to do instantaneous computation, it
    *  is pretty much necessary to set throwErrors to false.  Otherwise
    *  an error dialog would be put up every time the contents of the box
    *  changes to a value that does not define a legal number -- which can
    *  happen pretty often as the user is typing.  Ordinarily, a VariableInput
    *  will accept any constant expression, such as sqrt(2) - 6*pi, as
    *  input.  Here, I set the input style to VariableInput.REAL so that
    *  only actual real numbers will be acceptable.
    */ 
   
   private VariableInput makeInput(String name, MathBeanPanel panel, Parser parser) {
      VariableInput in = new VariableInput(name,0,parser);
      in.addTextListener(panel);
      in.setThrowErrors(false);
      in.setInputStyle(VariableInput.REAL);
      return in;
  }
  
 
  
 
  
} // end class ESSApplet
